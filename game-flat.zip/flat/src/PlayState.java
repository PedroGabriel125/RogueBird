import java.awt.*;
import java.awt.event.KeyEvent;

public class PlayState implements GameState {

    private final Game game;
    private float x = 100, y = 100, prevX = 100, prevY = 100;
    private static final float SPEED = 4f;

    public PlayState(Game game) { this.game = game; }

    @Override public void onEnter() {}
    @Override public void onExit()  {}

    @Override
    public void update() {
        if (game.keys.isJustPressed(KeyEvent.VK_ESCAPE)) {
            game.setState(new MenuState(game));
            return;
        }
        prevX = x; prevY = y;
        if (game.keys.isHeld(KeyEvent.VK_LEFT)  || game.keys.isHeld(KeyEvent.VK_A)) x -= SPEED;
        if (game.keys.isHeld(KeyEvent.VK_RIGHT) || game.keys.isHeld(KeyEvent.VK_D)) x += SPEED;
        if (game.keys.isHeld(KeyEvent.VK_UP)    || game.keys.isHeld(KeyEvent.VK_W)) y -= SPEED;
        if (game.keys.isHeld(KeyEvent.VK_DOWN)  || game.keys.isHeld(KeyEvent.VK_S)) y += SPEED;
        x = Math.max(0, Math.min(game.width  - 32, x));
        y = Math.max(0, Math.min(game.height - 32, y));
    }

    @Override
    public void render(Graphics2D g, float alpha) {
        float rx = prevX + (x - prevX) * alpha;
        float ry = prevY + (y - prevY) * alpha;

        g.setColor(Color.CYAN);
        g.fillRect((int) rx, (int) ry, 32, 32);
        g.setColor(Color.WHITE);
        g.drawRect((int) rx, (int) ry, 32, 32);

        g.setFont(new Font("Monospaced", Font.PLAIN, 14));
        g.setColor(Color.GRAY);
        g.drawString("WASD / Arrows   ESC = menu", 10, game.height - 10);
    }
}
