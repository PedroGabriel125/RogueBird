import java.awt.*;
import java.awt.event.KeyEvent;

public class MenuState implements GameState {

    private final Game game;
    private int tick;
    private boolean blink = true;

    public MenuState(Game game) { this.game = game; }

    @Override public void onEnter() { tick = 0; }
    @Override public void onExit()  {}

    @Override
    public void update() {
        if (++tick % 30 == 0) blink = !blink;
        if (game.keys.isJustPressed(KeyEvent.VK_ENTER))
            game.setState(new PlayState(game));
    }

    @Override
    public void render(Graphics2D g, float alpha) {
        int cx = game.width / 2, cy = game.height / 2;

        g.setColor(Color.WHITE);
        g.setFont(new Font("Monospaced", Font.BOLD, 48));
        FontMetrics fm = g.getFontMetrics();
        String title = "MY GAME";
        g.drawString(title, cx - fm.stringWidth(title) / 2, cy - 40);

        if (blink) {
            g.setFont(new Font("Monospaced", Font.PLAIN, 20));
            fm = g.getFontMetrics();
            String prompt = "Press ENTER to start";
            g.setColor(Color.LIGHT_GRAY);
            g.drawString(prompt, cx - fm.stringWidth(prompt) / 2, cy + 30);
        }
    }
}
